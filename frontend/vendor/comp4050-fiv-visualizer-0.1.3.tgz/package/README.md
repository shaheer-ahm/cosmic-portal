# Cosmic Visualizer

An interactive 3D React application for exploring Fit Portal datasets.

## Team Members

- Connell: Developer

## Stack

- React and TypeScript, built with Vite
- Three.js through React Three Fiber and Drei
- JSON Schema contracts validated with Ajv
- CSS Modules
- Vitest and React Testing Library for unit/component tests
- Playwright for browser integration tests
- GitHub Actions for continuous integration

## Getting started

Requires Node.js 20.19 or newer.

```bash
npm install
npm run dev
```

## Using the visualizer in another app

The package ships as a plain npm tarball, so consuming apps need no registry
configuration, no `.npmrc`, and no GitHub token.

### 1. Get the tarball

Download `comp4050-fiv-visualizer-<version>.tgz` from the
[Releases page](https://github.com/COMP4050-FiV/Cosmic-Visualizer/releases)
(any collaborator with repository access can download it from the browser).

To build one from a local checkout instead:

```bash
npm run pack:lib
```

### 2. Install it

Commit the tarball into the consuming repository (for example under `vendor/`)
so every developer and CI job installs the exact same build:

```bash
npm install ./vendor/comp4050-fiv-visualizer-0.1.1.tgz
```

This records a `file:` dependency in the consuming `package.json`:

```json
{
    "dependencies": {
        "@comp4050-fiv/visualizer": "file:vendor/comp4050-fiv-visualizer-0.1.1.tgz"
    }
}
```

`react` and `react-dom` 19 are peer dependencies and must already be installed.
Everything else the visualizer needs is bundled or installed automatically.

### 3. Render a box

```tsx
import {
    BoxDetailPage,
    parsePackResponse,
    type PackResponse,
} from "@comp4050-fiv/visualizer";
import "@comp4050-fiv/visualizer/style.css";

export function BoxRoute({ solverJson }: { solverJson: unknown }) {
    // Throws FitSolverContractError when the payload breaks the Fit Portal contract.
    const response: PackResponse = parsePackResponse(solverJson);

    return (
        <BoxDetailPage
            response={response}
            orderReference="ORD-2847"
            boxIndex={0}
            onBack={() => history.back()}
        />
    );
}
```

The Packing Instructions tab already shows the written packing steps. To use the
same steps somewhere else, such as a printout, build them from a box:

```ts
import { buildPackingSteps, whereText } from "@comp4050-fiv/visualizer";

const { steps, note } = buildPackingSteps(response.Boxes[0]);
// One step per item, in the solver's loading order: number, item, layer,
// spot ("Front-left corner"), walls, pose ("Keep it upright"), fragile.
whereText(steps[0]); // "On the box floor" or "On top of Base (step 1)"
// note is set when the solver's loading order is missing.
```

### 4. Upgrade

Drop the newer tarball into `vendor/`, delete the old one, and run
`npm install ./vendor/comp4050-fiv-visualizer-<new-version>.tgz`. The version in
the filename keeps npm from serving a cached copy of the previous build.

## Releasing a new version

1. Bump `version` in `package.json` and merge to `main`.
2. Tag the commit: `git tag v0.1.2 && git push origin v0.1.2`.
3. The `release` workflow runs lint and tests, builds the library, and attaches
   the tarball to the matching GitHub Release. It is also uploaded as a workflow
   artifact for tags and manual runs.

## Quality checks

```bash
npm run typecheck
npm test -- --run
npm run build
npm run test:e2e
```

## Team development workflow

Follow this workflow for every feature:

1. Create a GitHub issue from the Product Backlog.
2. Add acceptance criteria, an estimate, and any dependencies.
3. Move the issue from **Backlog** to **Ready**.
4. Assign one primary owner.
5. Create a branch using the appropriate prefix:

    - `feature/42-result-validator`
    - `fix/57-mobile-camera`
    - `chore/12-add-ci`

6. Move the issue to **In Progress**.
7. Open a draft pull request early.
8. Add the issue-closing keyword to the pull request description:

    ```text
    Closes #42
    ```

9. GitHub Actions runs automatically.
10. When implementation is complete, move the issue to **In Review**.
11. Another team member reviews the code and tests.
12. Resolve all review comments and obtain green CI.
13. Squash merge the pull request into `main`.
14. Confirm that the issue closes and moves to **Done**.
15. Demonstrate the completed work during the weekly meeting.

## Project layout

```text
schemas/                         Fit Portal JSON Schema contracts and examples
src/app/                         Application shell
src/components/                  Shared presentation components
src/features/visualization/      Three-dimensional visualization feature
src/integrations/fit-portal/     Contract types, parsing, and validation
src/styles/                      Global design tokens and base styles
src/test/                        Unit-test setup
tests/e2e/                       Playwright browser tests
```

See [docs/architecture.md](docs/architecture.md) for dependency boundaries and extension points.
